dofile(DATA_DIRECTORY .. "/lib/tables/teleport_item_destinations.lua")
dofile(DATA_DIRECTORY .. "/lib/tables/town.lua")

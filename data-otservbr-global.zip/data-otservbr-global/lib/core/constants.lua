GRADUATIONS = {
	ACADEMY = "Academy Student",
	GENIN = "Genin",
	CHUUNIN = "Chuunin",
	JOUNIN = "Jounin",
	SPECIAL_JOUNIN = "Special Jounin",
	ANBU = "Anbu",
	ROOT = "Root",
	SANNIN = "Sannin",
	KAGE = "Kage",
	NUKENIN = "Nukenin",
	JINCHUURIKI = "Jinchuuriki"
}
